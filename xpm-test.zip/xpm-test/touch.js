
module.exports = (command) => {
    console.log("successfully used package installed from the internet. '"+command+"'");
}