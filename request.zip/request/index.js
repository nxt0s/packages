module.exports = (command) => {
    let url = command.split(" ")[1];

    fetch(url)
    .then(resp=> resp.text()).then(body => console.log(body)) ;
}