const http = require("http");
module.exports = (command) => {
    let url = command.split(" ")[1];

    var options = {
        host: url,
        port: 80,
        path: ''
      };
      
    http.get(options, function(res) {
        console.log("Got response: " + res.statusCode);
    }).on('error', function(e) {
        console.log("Got error: " + e.message);
    });
}